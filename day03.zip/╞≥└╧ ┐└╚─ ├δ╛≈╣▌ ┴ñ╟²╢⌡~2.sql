-- drop sequence
drop SEQUENCE phonebook_seq;
-- drop table
DROP TABLE phonebook cascade CONSTRAINTS purge;

-- create sequence
create SEQUENCE phonebook_seq
    start with 1
    MAXVALUE 9999
    INCREMENT by 1
    nocache
    nocycle;
    -- �̷����� �⺻���� Ʋ

-- create table
CREATE TABLE phonebook(
    idx     number              default phonebook_seq.nextval primary key,
    name    VARCHAR2(100)       not null,
    AGE     NUMBER              check (0 < age and age < 1000),
	PNUM    VARCHAR2(20)        not null unique
);
    

-- insert into
insert into phonebook (name,age,pnum) values ('������',29,'010-1111-0111');
insert into phonebook (name,age,pnum) values ('���ܺ�',5,'010-5555-0555');
insert into phonebook (name,age,pnum) values ('ȫ��ȣ',42,'010-2222-2222');
insert into phonebook (name,age,pnum) values ('������',31,'010-3333-3331');

select * from phonebook;
select * from phonebook order by idx;
commit;