SELECT  * FROM employees;
    
SELECT department_id,max(salary) from employees
    GROUP BY department_id
    order by max(salary) desc;
    
SELECT  * FROM employees;       --107
SELECT  * FROM departments;     --27

SELECT  * FROM employees E
    join departments D
        on 1=1;   
          -- 1=1 true��� ��
        --2889(107*27) ���������� �����ش�.
        --- īƼ�þ� ���δ�Ʈ��� �Ѵ�. ������ �����ع����� �̷��� ���´�.

SELECT  
    * 
        FROM employees E
            join departments D
                on e.department_id = d.department_id;
                
SELECT  
    e.first_name,
    e.salary,
    d.department_name
        FROM employees E
        join departments D
                on e.department_id = d.department_id
        order by d.department_name;                
      
 SELECT  
   -- e.first_name,
   ceil( avg(e.salary)) as salary, --- ���� �Լ��� ���� 
   ---ceil �Ҽ��� ����
    d.department_name
        FROM employees E
        join departments D
                on e.department_id = d.department_id
        group by  d.department_name
        order by salary desc;       --- �� salary�� ��Ī
        
SELECT  
  
   min(e.salary) as salary,  
    d.department_name
        FROM employees E
        join departments D
                on e.department_id = d.department_id
        group by  d.department_name
        order by salary desc;      
        
SELECT  --- �μ� ���� ���� ������
   d.department_name,
   min(e.salary) as salary
        FROM employees E
        join departments D
                on e.department_id = d.department_id
        group by  d.department_name
        order by salary desc;         
        
SELECT  --- �ִ�
d.department_name,
   max(e.salary) as salary
        FROM employees E
        join departments D
                on e.department_id = d.department_id
        group by  d.department_name
        order by salary desc;     
        
SELECT  --- �հ�
d.department_name,
   sum(e.salary) as salary
        FROM employees E
        join departments D
                on e.department_id = d.department_id
        group by  d.department_name
        order by salary desc;   
        
 SELECT  --- �հ�
    d.department_id as �μ���ȣ,
    d.department_name as �μ���,
    count(e.salary) as �ο���,
   sum(e.salary) as ���޿�
        FROM employees E
        join departments D
                on e.department_id = d.department_id
        group by  d.department_name, d.department_id
        order by ���޿�
        desc;         
        
        commit