SELECT
    first_name, salary,hire_date
        FROM employees
    where
        EXTRACT(year from hire_date) >2005
        and
        salary >= 5000
    order by 
        salary desc, first_name ;
        
SELECT
    avg(salary) 
        from employees;
        
SELECT
    floor (avg(salary)) ---  �Ҽ��� ���� ������
        from employees;
        
SELECT
    ceil (avg(salary)) --- �Ҽ��� ���� �ݿø��ؼ� ������
        from employees;     
        
--CREATE SEQUENCE 
SELECT
    city,
    count(DEPARTMENT_name) as cnt
    FROM departments
    join LOCATIONS
        on departments.location_id = locations.location_id
    group by city
    order by cnt desc;
    
SELECT
    department_name,
    city,
    country_id
  
    FROM departments
    join LOCATIONS
        on departments.location_id = locations.location_id;
        
        
SELECT
    department_name,
    city,
    case 
        WHEN country_id = 'US' then '�̱�'
        WHEN country_id = 'UK' then '����'
        WHEN country_id = 'CA' then 'ĳ����'
        WHEN country_id = 'DE' then '����'
    end as ����    
    --- case�� end�� �Բ� ��� �Ѵ�.  
    FROM departments
    join LOCATIONS
        on departments.location_id = locations.location_id;       
        
create user c##hyeran identified by ran;

SELECT BANNER FROM V$VERSION;

ALTER USER C##ITBANK IDENTIFIED BY IT;

ALTER user c##itbank IDENTIFIED by it;

CREATE SEQUENCE COSTOMERS_SEQ
START with 1000
INCREMENT by 1
NOCACHE
NOCYCLE;

SELECT
    * 
    FROM MEMBER
    WHERE GENDER = '����' AND AGE >= 30;
    


